export class Chamados{
    id:	number;
    descricao:	string;
    fila:	string;
    }